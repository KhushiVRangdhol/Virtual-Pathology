import cv2
import numpy as np
import re


def read_keypoints(keypoints_file_dir, name_prefix):
    list_he = []
    list_gray = []

    with open(keypoints_file_dir + name_prefix + '_labeling.txt', 'r') as f:
        while 1:
            line = f.readline().strip('\n')
            if not line:
                break
            # print(line)
            x = re.split(r'[\t,]', line)

            list_he.append((int(x[0]), int(x[1].strip(' ').strip(')'.strip(' ')))))
            list_gray.append((int(x[2]), int(x[3].strip(' ').strip(')'.strip(' ')))))
        
    print(len(list_he))
    print(list_he)
    print(len(list_gray))
    print(list_gray)
    return list_he, list_gray


if __name__ == '__main__':
    # H, status = cv2.findHomography(image2_kp, image1_kp, cv2.RANSAC,5.0)
    

    # name_prefix = '19ah7970'
    # name_prefix = '19ah7973a'
    # name_prefix = '19ah7973b'
    # name_prefix = '19ah7974a'
    # name_prefix = '19ah7974b'
    # name_prefix = '19ah7975'
    # name_prefix = '19ah7976'
    # name_prefix = '19ah7978'
    # name_prefix = '19ah7980'
    # name_prefix = '19ah7983-1'
    # name_prefix = '19ah7983-2a'
    # name_prefix = '19ah7983-2b'
    # name_prefix = '19ah7985-1'
    # name_prefix = '19ah7986-1a'
    # name_prefix = '19ah7986-1b'
    # name_prefix = '19ah7987'
    # name_prefix = '19ah7988-2a'
    # name_prefix = '19ah7988-2b'
    # name_prefix = '19ah8023'
    # name_prefix = '19ah8024'
    # name_prefix = '19ah8025'
    # name_prefix = '19ah8027a'
    # name_prefix = '19ah8027b'
    # name_prefix = '19ah8028'
    # name_prefix = '19ah8029a'
    # name_prefix = '19ah8029b'
    name_prefix = '19ah8030'
    # name_prefix = ''
    print(name_prefix)

    img_source_dir = '/media/cz/Data/Data/stain/original/Images_052019_tif/'
    save_dir = '/media/cz/Data/Code/PhaseStain/cz_implement/registered_dataset/'

    gray_img = img_source_dir + name_prefix + '.tif'
    he_img = img_source_dir + name_prefix + ' (h&ex2.4).tif'
    gray_img = cv2.imread(gray_img, cv2.IMREAD_GRAYSCALE)
    he_img = cv2.imread(he_img)

    keypoints_file_dir = '/media/cz/PRINT/files/histology/labeling/'
    keypoints_HE, keypoints_gray = read_keypoints(keypoints_file_dir, name_prefix) 

    H, status = cv2.findHomography(np.array(keypoints_HE), np.array(keypoints_gray), cv2.RANSAC,5.0)
    print(H)
    with open('./homography_matrix/'+name_prefix+'.txt', 'w') as f:
        f.writelines(str(H))


    he_mask = np.ones((he_img.shape[0], 2*he_img.shape[1]))
    affined_he_mask = cv2.warpPerspective(he_mask[:, :], H, (gray_img.shape[1], gray_img.shape[0]))

    affined_save_dir = '/media/cz/Data/Code/PhaseStain/cz_implement/registered_mask/'
    cv2.imwrite(affined_save_dir+name_prefix+'_affined_mask.png', 255*affined_he_mask)

    mask = np.zeros((gray_img.shape[0], 2*gray_img.shape[1],3))
    mask[:gray_img.shape[0],:gray_img.shape[1], 0] = gray_img * affined_he_mask
    mask[:gray_img.shape[0],:gray_img.shape[1], 1] = gray_img * affined_he_mask
    mask[:gray_img.shape[0],:gray_img.shape[1], 2] = gray_img * affined_he_mask

    mask[:gray_img.shape[0], gray_img.shape[1]:] = \
        cv2.warpPerspective(he_img[:, :,:], H, (gray_img.shape[1], gray_img.shape[0]))
    cv2.imwrite(save_dir+'registered_pair/'+name_prefix+'_pair.png', mask)

    cv2.imwrite(save_dir + name_prefix + '.png', gray_img * affined_he_mask)
    cv2.imwrite(save_dir + name_prefix +'_h&ex2.4.png', cv2.warpPerspective(he_img[:, :,:], H, (gray_img.shape[1], gray_img.shape[0])))

# if __name__ == '__main__':

#     gray_img = '19ah7970.tif'
#     he_img = '19ah7970_h&ex2.4.tif'
#     gray_img = cv2.imread(gray_img, cv2.IMREAD_GRAYSCALE)
#     he_img = cv2.imread(he_img)

#     mask = np.zeros((he_img.shape[0], gray_img.shape[1]+he_img.shape[1], 3))
#     mask[:gray_img.shape[0], :gray_img.shape[1], 0] = gray_img
#     mask[:gray_img.shape[0], :gray_img.shape[1], 1] = gray_img
#     mask[:gray_img.shape[0], :gray_img.shape[1], 2] = gray_img

#     mask[:, gray_img.shape[1]:, :] = he_img

#     cv2.imwrite('non-registered_pair.png', mask)


